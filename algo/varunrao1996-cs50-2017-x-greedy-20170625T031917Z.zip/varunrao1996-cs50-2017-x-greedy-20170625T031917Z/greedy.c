#include<cs50.h>
#include<stdio.h>
#include<math.h>
int main(void)
{
    float amount;
    do
    {
        printf("o hai! How much change is owed?\n");
        amount=get_float();
    }
   while(amount<0);
   int noofcoins,change;
   noofcoins=0;
   change=round(amount*100);
   noofcoins+=change/25;
   change%=25;
   noofcoins+=change/10;
   change=change%10;
   noofcoins+=change/5;
   change=change%5;
   noofcoins+=change;
   printf("%d\n",noofcoins);
}