#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>
char caesar(char character, int key)
{
    if (isupper(character))
    {
        return ((character - 'A' + key) % 26) + 'A';    
    }
    else
    {
        return ((character - 'a' + key) % 26) + 'a';
    }
}
int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./vigenere k \n");
        return 1;
    }
    int keylength = strlen(argv[1]);
    for (int k = 0; k < keylength; k++)
    {
        if (!isalpha(argv[1][k]))
        {
            printf("Usage: ./vigenere k\n");
            return 1;
        }
    }
    printf("plaintext:   ");
    string text = get_string();
    printf("ciphertext:   ");
    int textlength = strlen(text);
    int key[textlength];
    for (int i = 0, j = 0; i < textlength; i++)
    {
        if (isalpha(text[i]))
        {
            key[i] = tolower(argv[1][j % keylength]) - 'a';
            j++;
            printf("%c", caesar(text[i], key[i]));
        }
        else
        {
            printf("%c", text[i]); 
        }
    }
    printf("\n");
    return 0;
}
