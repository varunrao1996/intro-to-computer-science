#include<cs50.h>
#include<stdio.h>
int main()
{
    int height,i,j,k;
    do
    {
        printf("height: ");
        height=get_int();
    }
    while(height<0 || height>23);
    for(i=0;i<height;i++)
    {
        for(j=height-i-1;j>0;j--)
        printf(" ");
        for(k=0;k<i+2;k++)
        printf("#");
        printf("\n");
    }
}