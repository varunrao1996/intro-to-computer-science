#include<stdio.h>
#include<string.h>
#include<cs50.h>
#include<ctype.h>
int main(void)
{
    string name=get_string();
    if(name!=NULL)
    {
        int i=0;
        printf("%c",toupper(name[i]));
        for(i=1;i<strlen(name);i++)
        {
            if(name[i]==' ')
            {
                printf("%c",toupper(name[i+1]));
            }
            
        }
        printf("\n");
        
    }
}