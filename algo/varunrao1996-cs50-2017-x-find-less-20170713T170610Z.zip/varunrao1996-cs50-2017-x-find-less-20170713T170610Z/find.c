#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include "helpers.h"
const int MAX = 65536;
bool search(int value, int values[], int n)
{
    int min = 0, max = n - 1, mid;
    while ((max - min + 1) > 0)
    {
        mid = (max - min + 1)/ 2 + min;
        if (values[mid] == value)
        {
            return true;
        }
        else if (values[mid] < value)
        {       
            min = mid + 1;
        }
        else if (values[mid] > value)
        {
            max = mid - 1;
        }
    }
    return false;
}
void sort(int values[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for(int j = i + 1, min; j < n; j++)
        {
            if (values[i] > values[j])
            {
                min = values[j];
                values[j] = values[i];
            }
            else 
            {
                min = values[i];
            } 
            values[i] = min;
        } 
    }
    for (int i = 0; i < n; i++)
    {
        printf("%d\n", values[i]);
    }
}
int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./find needle\n");
        return -1;
    }

    int needle = atoi(argv[1]);
    int s;
    int haystack[MAX];
    for (s= 0; s < MAX; s++)
    {
        printf("\nhaystack[%d] = ", s);
        int straw = GetInt();
        if (straw == INT_MAX)
        {
            break;
        }
        haystack[s] = straw;
    }
    printf("\n");
    sort(haystack, s);
    if (search(needle, haystack,s))
    {
        printf("\nFound needle in haystack!\n\n");
        return 0;
    }
    else
    {
        printf("\nDid not find needle in haystack.\n\n");
        return 1;
    }
}