#include <cs50.h>
bool search(int value, int values[], int n);
void sort(int values[], int n);