
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, string argv[])
{   
    if (argc != 2) 
    {
        printf("Usage: ./caesar k\n");
        return 1;
    }
    else 
    {
        int key = atoi(argv[1]); 
        printf("plaintext:   ");
        string text = get_string();
        printf("ciphertext:   ");
        for (int i = 0, n = strlen(text); i < n; i++)
        {
            char letter = text[i];
            int result;
            if (isupper(letter))
            {
                result = ((letter - 65) + key) % 26 + 65;
            } 
            else if (islower(letter))
            {
                result = ((letter - 97) + key) % 26 + 97;
            }
            else
            {
                result = letter;
            }
            printf("%c", result);
         }   
         printf("\n");
    }
}




